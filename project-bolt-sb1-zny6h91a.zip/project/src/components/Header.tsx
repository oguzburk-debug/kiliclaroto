import { Building2 } from 'lucide-react';

export default function Header() {
  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <Building2 className="text-blue-600" size={32} />
            <span className="text-2xl font-bold text-gray-900">Premium İlanlar</span>
          </div>
          <nav className="hidden md:flex items-center gap-8">
            <a href="#" className="text-gray-700 hover:text-blue-600 font-medium transition-colors">
              Ana Sayfa
            </a>
            <a href="#" className="text-gray-700 hover:text-blue-600 font-medium transition-colors">
              Gayrimenkul
            </a>
            <a href="#" className="text-gray-700 hover:text-blue-600 font-medium transition-colors">
              Otomotiv
            </a>
            <a href="#" className="text-gray-700 hover:text-blue-600 font-medium transition-colors">
              İletişim
            </a>
          </nav>
        </div>
      </div>
    </header>
  );
}
