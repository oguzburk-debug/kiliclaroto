import { Calendar, Gauge, Fuel, Cog } from 'lucide-react';

interface Vehicle {
  id: number;
  title: string;
  brand: string;
  year: number;
  price: string;
  mileage: string;
  fuel: string;
  transmission: string;
  image: string;
}

interface VehicleCardProps {
  vehicle: Vehicle;
}

export default function VehicleCard({ vehicle }: VehicleCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
      <div className="relative h-64 overflow-hidden">
        <img
          src={vehicle.image}
          alt={vehicle.title}
          className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute top-4 right-4 bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-semibold">
          {vehicle.year}
        </div>
      </div>
      <div className="p-6">
        <div className="text-sm text-gray-500 mb-1">{vehicle.brand}</div>
        <h3 className="text-xl font-bold text-gray-900 mb-4">{vehicle.title}</h3>
        <div className="grid grid-cols-2 gap-3 mb-4 text-sm text-gray-600">
          <div className="flex items-center gap-2">
            <Calendar size={16} />
            <span>{vehicle.year}</span>
          </div>
          <div className="flex items-center gap-2">
            <Gauge size={16} />
            <span>{vehicle.mileage}</span>
          </div>
          <div className="flex items-center gap-2">
            <Fuel size={16} />
            <span>{vehicle.fuel}</span>
          </div>
          <div className="flex items-center gap-2">
            <Cog size={16} />
            <span>{vehicle.transmission}</span>
          </div>
        </div>
        <div className="flex items-center justify-between pt-4 border-t border-gray-200">
          <span className="text-2xl font-bold text-blue-600">{vehicle.price}</span>
          <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors font-medium">
            Detaylar
          </button>
        </div>
      </div>
    </div>
  );
}
