import { useState } from 'react';
import { Home, Car, MapPin, Calendar, Gauge, Fuel, Phone, Mail } from 'lucide-react';
import PropertyCard from './components/PropertyCard';
import VehicleCard from './components/VehicleCard';
import Header from './components/Header';
import Hero from './components/Hero';
import { properties, vehicles } from './data/listings';

function App() {
  const [activeTab, setActiveTab] = useState<'property' | 'vehicle'>('property');

  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      <Hero />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex justify-center mb-12">
          <div className="inline-flex rounded-lg bg-white shadow-sm p-1">
            <button
              onClick={() => setActiveTab('property')}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all ${
                activeTab === 'property'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <Home size={20} />
              Gayrimenkul
            </button>
            <button
              onClick={() => setActiveTab('vehicle')}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all ${
                activeTab === 'vehicle'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <Car size={20} />
              Otomotiv
            </button>
          </div>
        </div>

        {activeTab === 'property' ? (
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-8">Gayrimenkul İlanları</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {properties.map((property) => (
                <PropertyCard key={property.id} property={property} />
              ))}
            </div>
          </div>
        ) : (
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-8">Otomotiv İlanları</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {vehicles.map((vehicle) => (
                <VehicleCard key={vehicle.id} vehicle={vehicle} />
              ))}
            </div>
          </div>
        )}
      </div>

      <footer className="bg-gray-900 text-white py-12 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">İletişim</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Phone size={18} />
                  <span>+90 555 123 45 67</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail size={18} />
                  <span>info@example.com</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin size={18} />
                  <span>İstanbul, Türkiye</span>
                </div>
              </div>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-4">Hakkımızda</h3>
              <p className="text-gray-400">
                Gayrimenkul ve otomotiv sektöründe güvenilir çözümler sunuyoruz.
              </p>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-4">Çalışma Saatleri</h3>
              <p className="text-gray-400">Pazartesi - Cuma: 09:00 - 18:00</p>
              <p className="text-gray-400">Cumartesi: 09:00 - 14:00</p>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Tüm hakları saklıdır.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
